export interface ResponseType {
    msg: string;

}