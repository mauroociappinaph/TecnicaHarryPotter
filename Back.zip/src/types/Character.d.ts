export interface Character {
    _id: string;
    name: string;
    image: string;
    house: string;
}