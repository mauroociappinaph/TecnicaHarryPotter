const Footer = () => {
  return (
    <footer className="py-10">
      <span className="text-indigo-600">Harry Potter &copy; 2024</span>
    </footer>
  );
};

export default Footer;
