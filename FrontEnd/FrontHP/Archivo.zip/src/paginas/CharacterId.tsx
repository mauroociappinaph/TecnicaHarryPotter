import CardId from "../components/CardId";
const CharacterId = () => {
  return (
    <div>
      <CardId />
    </div>
  );
};

export default CharacterId;
