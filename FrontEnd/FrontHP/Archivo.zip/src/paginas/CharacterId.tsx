const CharacterId = () => {
  return (
    <div>
      <h1>Character</h1>
    </div>
  );
};

export default CharacterId;
