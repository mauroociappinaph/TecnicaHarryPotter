const Registrar = () => {
  return (
    <div>
      <h1>Registrar</h1>
    </div>
  );
};

export default Registrar;
