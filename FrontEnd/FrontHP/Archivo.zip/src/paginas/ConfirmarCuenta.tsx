const ConfirmarCuenta = () => {
  return <div>ConfirmarCuenta</div>;
};

export default ConfirmarCuenta;
