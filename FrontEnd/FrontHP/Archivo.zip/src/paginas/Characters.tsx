const Characters = () => {
  return <div>Characters</div>;
};

export default Characters;
