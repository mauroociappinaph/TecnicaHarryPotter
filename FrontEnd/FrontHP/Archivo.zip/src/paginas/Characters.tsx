import Cards from "../components/Card";
const Characters = () => {
  return <Cards />;
};

export default Characters;
