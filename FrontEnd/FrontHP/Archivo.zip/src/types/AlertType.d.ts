export interface AlertaType {
    msg: string;
    error: boolean;
}